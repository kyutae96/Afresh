package com.example.markcloudproject;
import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;


public class Result2Activity extends Activity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.result2);

        Bitmap bit = null; // 변환시킬 비트맵
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bit.compress(Bitmap.CompressFormat.JPEG , 100 , stream);
        byte[] b = stream.toByteArray();



    }

}
